import * as _angular_core from '@angular/core';
import * as first_library from 'first-library';

declare class Card {
    title: _angular_core.InputSignal<string>;
    subtitle: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Card, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Card, "lib-card", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class Button {
    label: _angular_core.InputSignal<string>;
    variant: _angular_core.InputSignal<"primary" | "secondary" | "danger">;
    disabled: _angular_core.InputSignal<boolean>;
    pressed: _angular_core.OutputEmitterRef<void>;
    onClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Button, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Button, "lib-button", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "pressed": "pressed"; }, never, ["*"], true, never>;
}

declare class Notification {
    private readonly notificationService;
    readonly notification: _angular_core.Signal<first_library.NotificationState>;
    hide(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Notification, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Notification, "lib-notification", never, {}, {}, never, never, true, never>;
}

interface NotificationState {
    message: string;
    type: 'success' | 'error' | 'info';
    visible: boolean;
}

declare class NotificationServiceTs {
    private readonly stateSignal;
    readonly state: _angular_core.Signal<NotificationState>;
    showSuccess(message: string): void;
    showError(message: string): void;
    showInfo(message: string): void;
    hide(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NotificationServiceTs, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<NotificationServiceTs>;
}

interface FirstLibraryConfigInterfaceTs {
}

export { Button, Card, Notification, NotificationServiceTs };
export type { FirstLibraryConfigInterfaceTs, NotificationState };
